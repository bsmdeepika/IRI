package com.infosys.irs.InfyGo_SpringCore;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.infosys.irs.InfyGo_SpringCore.model.User;
import com.infosys.irs.InfyGo_SpringCore.service.RegistrationService;

@SpringBootApplication
@PropertySource(value= {
		"classpath:configuration.properties"
})

public class InfyGoApplication implements CommandLineRunner {
	
	@Autowired
	private Environment environment;
	@Autowired
	ApplicationContext context;
	public static void main(String[] args) {
		
		SpringApplication.run(InfyGoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		try {
			User user=new User();
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter user id:");
			String uid=sc.next();
			System.out.println("Enter password:");
			String pwd=sc.next();
			System.out.println("Enter name:");
			String name=sc.next();
System.out.println("Enter phone:");
			
			String phone=sc.next();
			
			System.out.println("Enter city:");
			
			String city=sc.next();
			
			System.out.println("Enter email:");
			
			String email=sc.next();
			
			
			
			user.setCity(city);
			user.setEmail(email);
			user.setName(name);
			user.setPhone(phone);
			user.setPassword(pwd);
			user.setUserId(uid);
			
			RegistrationService registrationservice=(RegistrationService) context.getBean("registrationService");
			
			String registrationMessage=registrationservice.registerUser(user);
			
			System.out.println(environment.getProperty(registrationMessage));
			
			
		}
		catch(Exception e) {
			System.out.println(environment.getProperty(e.getMessage()));
		}
	}

}
