package com.infosys.irs.InfyGo_SpringCore.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.irs.InfyGo_SpringCore.exception.InfyGoBootException;
import com.infosys.irs.InfyGo_SpringCore.exception.InvalidCityException;
import com.infosys.irs.InfyGo_SpringCore.exception.InvalidEmailException;
import com.infosys.irs.InfyGo_SpringCore.exception.InvalidNameException;
import com.infosys.irs.InfyGo_SpringCore.exception.InvalidPasswordException;
import com.infosys.irs.InfyGo_SpringCore.exception.InvalidPhoneException;
import com.infosys.irs.InfyGo_SpringCore.exception.InvalidUserIdException;
import com.infosys.irs.InfyGo_SpringCore.model.User;
import com.infosys.irs.InfyGo_SpringCore.repository.UserRepository;

@Service
public class RegistrationService {
	@Autowired
	private UserRepository userRepository;
	
	String regex1= "^[a-zA-Z0-9]{4,15}+$";
	public String registerUser(User user) throws InfyGoBootException{
		String registrationMessage=null;
		
		validateUser(user);
		 registrationMessage=userRepository.registerUser();
		return registrationMessage;
		
	}
	private void validateUser(User user) throws InfyGoBootException{
		// TODO Auto-generated method stub
		if(!isValidUserId(user.getUserId()))
			throw new InvalidUserIdException("RegistrationService.INVALID_USER_ID");
		if(!isValidPassword(user.getPassword()))
		throw new InvalidPasswordException("RegistrationService.INVALID_PASSWORD");
		
		if(!isValidName(user.getName())) 
			throw new InvalidNameException("RegistrationService.INVALID_NAME");
		if(!isValidCity(user.getCity()))
			throw new InvalidCityException("RegistrationService.INVALID_CITY");
		
		if(!isValidEmail(user.getEmail()))
			
		throw new InvalidEmailException("RegistrationService.INVALID_EMAIL");
		
		if(!isValidPhoneNumber(user.getPhone()))
			
		throw new InvalidPhoneException("RegistrationService.INVALID_PHONE_NUMBER");
		
	}
	private boolean isValidPhoneNumber(String phone) {
		// TODO Auto-generated method stub
		Boolean b1=false;
		String regex4="[0-9]{10}";
		Pattern pattern6=Pattern.compile(regex4);
		Matcher matcher6=pattern6.matcher(phone);
		if(matcher6.matches())
			b1=true;
		
		return b1;
	}
	private boolean isValidEmail(String email) {
		// TODO Auto-generated method stub
		Boolean b1=false;
		String regex3="^[A-Za-z0-9+_.-]+@(.+)$";
		Pattern pattern5=Pattern.compile(regex3);
		Matcher matcher5=pattern5.matcher(email);
		if(matcher5.matches())
			b1=true;
		return b1;
	}
	private boolean isValidCity(String city) {
		// TODO Auto-generated method stub
		Boolean b1=false;
		Pattern pattern4=Pattern.compile(regex1);
		Matcher matcher4=pattern4.matcher(city);
		if(matcher4.matches())
			b1=true;
		
		return b1;
	}
	private boolean isValidName(String name) {
		// TODO Auto-generated method stub
		
		Boolean b1=false;
		Pattern pattern3=Pattern.compile(regex1);
		Matcher matcher3=pattern3.matcher(name);
		if(matcher3.matches())
			b1=true;
		return b1;
	}
	private boolean isValidPassword(String password) {
		// TODO Auto-generated method stub
		Boolean b1=false;
		String regex2="^[a-zA-Z0-9]{8,15}+$";
		
		Pattern pattern2=Pattern.compile(regex2);
		Matcher matcher2=pattern2.matcher(password);
		if(matcher2.matches())
			b1=true;
		return b1;
	}
	private boolean isValidUserId(String userId) {
		// TODO Auto-generated method stub
		Boolean b1=false;
		Pattern pattern1=Pattern.compile(regex1);
		Matcher matcher1=pattern1.matcher(userId);
		if(matcher1.matches())
			b1=true;
		
		return b1;
	}

}
