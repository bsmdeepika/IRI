package com.infosys.irs.InfyGo_SpringCore.exception;

public class InvalidNameException extends InfyGoBootException{
	private static final long SerialVersionUID=1L;
	public InvalidNameException(String message) {
		super(message);
	}
}
