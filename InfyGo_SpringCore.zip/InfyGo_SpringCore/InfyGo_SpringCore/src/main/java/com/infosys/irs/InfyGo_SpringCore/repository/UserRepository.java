package com.infosys.irs.InfyGo_SpringCore.repository;

import org.springframework.stereotype.Component;

@Component
public class UserRepository {
	
	private String successMessage="User_Repository.REGISTRATION_SUCCESS";
	public String registerUser() {
		return successMessage;
	}

}
