package com.infosys.irs.InfyGo_SpringCore.exception;

public class InfyGoBootException extends Exception {
	
	private static final long serialVersionUID=1L;
	
	public InfyGoBootException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
