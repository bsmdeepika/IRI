package com.infosys.irs.InfyGo_SpringCore.exception;

public class InvalidEmailException extends InfyGoBootException 
{
	private static final long SerialVersionUID=1L;
	public InvalidEmailException(String message) {
		super(message);
	}

}
