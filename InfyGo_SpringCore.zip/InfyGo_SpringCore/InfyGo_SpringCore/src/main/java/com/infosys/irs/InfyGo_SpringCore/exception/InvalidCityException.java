package com.infosys.irs.InfyGo_SpringCore.exception;

public class InvalidCityException extends InfyGoBootException{
	

	private static final long SerialVersionUID=1L;
	public InvalidCityException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
