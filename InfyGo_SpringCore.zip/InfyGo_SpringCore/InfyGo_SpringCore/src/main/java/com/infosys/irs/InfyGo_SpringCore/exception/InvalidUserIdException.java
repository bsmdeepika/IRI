package com.infosys.irs.InfyGo_SpringCore.exception;

public class InvalidUserIdException extends InfyGoBootException {
	private static final long SerialVersionUID=1L;
	public InvalidUserIdException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
