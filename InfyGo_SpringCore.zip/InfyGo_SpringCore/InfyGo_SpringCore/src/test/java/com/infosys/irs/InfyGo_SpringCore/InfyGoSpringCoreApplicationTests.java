package com.infosys.irs.InfyGo_SpringCore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfyGoSpringCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
